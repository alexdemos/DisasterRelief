package com.example.disasterrelief;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Update_Numbers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update__numbers);
        setTitle("Update Phone Numbers");
    }



    public void main(View view) {
        EditText localPolice = (EditText) findViewById(R.id.local_police);
        String localPoliceNum = localPolice.getText().toString();
        phoneNums.setPolice(localPoliceNum);

        EditText localUtilities = (EditText) findViewById(R.id.local_utility);
        String localUtilityNum = localPolice.getText().toString();
        phoneNums.setUtility(localUtilityNum);

        EditText localMedical = (EditText) findViewById(R.id.local_medical);
        String localMedicalNum = localPolice.getText().toString();
        phoneNums.setMedical(localMedicalNum);

        EditText localHiWay = (EditText) findViewById(R.id.local_highway);
        String localHiWayNum = localPolice.getText().toString();
        ((phoneNums) this.getApplication()).setHighway(localHiWayNum);

    }

    public void back(View view){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }

}
