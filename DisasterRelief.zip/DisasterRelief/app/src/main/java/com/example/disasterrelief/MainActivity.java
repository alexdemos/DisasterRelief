package com.example.disasterrelief;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void update_nums(View view){
        Intent intent = new Intent(this,Update_Numbers.class);
        startActivity(intent);
    }

    public void yes(View view){
        Intent intent = new Intent(this,YesLifeThreat.class);
        startActivity(intent);
    }

    public void no(View view){
        Intent intent = new Intent(this,NoLifeThreat.class);
        startActivity(intent);
    }
}
