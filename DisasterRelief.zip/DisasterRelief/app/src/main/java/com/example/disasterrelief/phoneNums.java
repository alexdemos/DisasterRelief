package com.example.disasterrelief;

import android.app.Application;

public class phoneNums extends Application {
    private  String highway;
    private static String police;
    private static String medical;
    private static String utility;

    public String getHighway(){
        return highway;
    }

    public void setHighway(String s){
        this.highway = s;
    }

    public static String getPolice(){
        return police;
    }

    public static void setPolice(String s){
        police = s;
    }

    public static String getMedical(){
        return medical;
    }

    public static void setMedical(String s){
        medical = s;
    }

    public static String getUtility(){
        return utility;
    }

    public static void setUtility(String s){
        utility = s;
    }


}
